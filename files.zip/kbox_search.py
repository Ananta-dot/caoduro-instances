#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kbox_search.py — search integration for k-box MISR instances.

CORRECTED VERSION WITH ROBUST SAVING.

Every round's best (if >= SAVE_THRESHOLD) is pickled to elites_above_threshold/.
A final summary pickle is always written to run_outputs/, even on Ctrl+C.

Usage:
    python3 kbox_search.py --smoke
    python3 kbox_search.py --save-smoke
    python3 kbox_search.py --verify-all
    python3 kbox_search.py --run --k-start 9 --k-end 10 --rounds 5

Output locations (relative to cwd):
    elites_above_threshold/  — every elite with ratio >= SAVE_THRESHOLD (1.40)
    run_outputs/             — final summary + full elite pool
"""

from __future__ import annotations

import argparse
import os
import pickle
import random
import sys
import time
import traceback
from collections import Counter, defaultdict
from typing import Callable, Dict, List, Optional, Sequence, Set, Tuple

from kbox_misr import (
    kbox_instance,
    kbox_instance_with_key_map,
    _kbox_geom,
    verify,
    expected_edges,
    actual_edges,
    triangle_free,
    explicit_IS_labels,
    Seq, Instance,
)

try:
    from mistr_runner import (
        canonicalize,
        instance_key,
        seq_spans,
        build_rects,
        grid_points,
        covers_grid_closed,
        solve_lp_ilp,
        random_valid_seq,
        motif_seeds,
    )
    _HAS_MISTR = True
except Exception:
    _HAS_MISTR = False
    from kbox_misr import (  # noqa: F401
        canonicalize, instance_key, seq_spans, build_rects,
        grid_points, covers_grid_closed,
    )

    def random_valid_seq(n: int, rng: random.Random) -> Seq:
        seq = [i for i in range(1, n + 1) for _ in range(2)]
        rng.shuffle(seq)
        return seq

    def motif_seeds(n: int) -> List[Seq]:
        rainbow = list(range(1, n + 1)) + list(range(n, 0, -1))
        doubled = [x for i in range(1, n + 1) for x in (i, i)]
        return [rainbow, doubled]

    solve_lp_ilp = None


# =========================================================================== #
# Save configuration                                                           #
# =========================================================================== #

SAVE_THRESHOLD = 1.40
ELITES_DIR = "elites_above_threshold"
FINAL_DIR = "run_outputs"


# =========================================================================== #
# 1. Seed pool generator                                                       #
# =========================================================================== #


def _box_membership(k: int) -> Dict[int, List[int]]:
    (_H, _V), key_to_lab = kbox_instance_with_key_map(k)
    by_box: Dict[int, List[int]] = defaultdict(list)
    for (kind, a, i), lab in key_to_lab.items():
        by_box[a].append(lab)
    for a in by_box:
        by_box[a].sort()
    return dict(by_box)


def shuffle_boxes(H: Seq, V: Seq, k: int, rng: random.Random) -> Instance:
    """Randomly permute the k boxes along the diagonal."""
    by_box = _box_membership(k)
    boxes = list(range(1, k + 1))
    perm = boxes[:]
    rng.shuffle(perm)
    relabel: Dict[int, int] = {}
    for a_idx, a_new in enumerate(perm):
        a_old = boxes[a_idx]
        old_labs = by_box[a_old]
        new_labs = by_box[a_new]
        for o, n in zip(old_labs, new_labs):
            relabel[o] = n
    H2 = [relabel[x] for x in H]
    V2 = [relabel[x] for x in V]
    return canonicalize(H2, V2)


def swap_within_box(H: Seq, V: Seq, k: int, box: int,
                    rng: random.Random) -> Instance:
    """Swap two same-kind segments inside a single k-box."""
    (_H0, _V0), key_to_lab = kbox_instance_with_key_map(k)
    by_kind: Dict[str, List[int]] = defaultdict(list)
    for (kind, a, i), lab in key_to_lab.items():
        if a == box:
            by_kind[kind].append(lab)
    candidates = [kind for kind, labs in by_kind.items() if len(labs) >= 2]
    if not candidates:
        return canonicalize(H, V)
    kind = rng.choice(candidates)
    labs = by_kind[kind]
    a, b = rng.sample(labs, 2)
    relabel = {a: b, b: a}
    H2 = [relabel.get(x, x) for x in H]
    V2 = [relabel.get(x, x) for x in V]
    return canonicalize(H2, V2)


def perturb_segment_extent(H: Seq, V: Seq, rng: random.Random,
                           which: str = "auto") -> Instance:
    """Slide one of a label's positions by +/- 1 step."""
    n = max(max(H), max(V))
    if which == "auto":
        which = rng.choice(("H", "V"))
    S = list(H if which == "H" else V)
    lab = rng.randint(1, n)
    positions = [i for i, x in enumerate(S) if x == lab]
    if len(positions) != 2:
        return canonicalize(H, V)
    i = rng.choice(positions)
    direction = rng.choice((-1, 1))
    j = i + direction
    if not (0 <= j < len(S)):
        return canonicalize(H, V)
    if S[j] == lab:
        return canonicalize(H, V)
    S[i], S[j] = S[j], S[i]
    if which == "H":
        return canonicalize(S, V)
    return canonicalize(H, S)


def load_pickle_elites(k: int, elites_dir: str = "elites_above_threshold",
                       max_elites: int = 8,
                       min_gap: float = 0.0,
                       require_triangle_free: bool = False
                       ) -> List[Tuple[float, Seq, Seq]]:
    """
    Scan elites_dir for pickle files matching target k and load the top
    max_elites by gap. Returns a list of (gap, H, V) sorted descending.

    Filters by:
      - k matches (from the pickle's 'k' field or filename kN)
      - n matches 4*k*k (sanity check)
      - gap >= min_gap
      - optionally, triangle_free if require_triangle_free=True

    Silently skips malformed pickles; prints a summary of what was loaded.
    """
    if not os.path.isdir(elites_dir):
        return []

    target_n = 4 * k * k
    loaded: List[Tuple[float, Seq, Seq]] = []
    scanned = 0
    skipped = 0

    for fname in os.listdir(elites_dir):
        if not fname.endswith(".pkl"):
            continue
        path = os.path.join(elites_dir, fname)
        scanned += 1
        try:
            with open(path, "rb") as f:
                d = pickle.load(f)
        except Exception:
            skipped += 1
            continue

        pk = d.get("k", None)
        # if k field missing, try parsing from filename "kN_r..."
        if pk is None and fname.startswith("k"):
            try:
                pk = int(fname.split("_")[0][1:])
            except Exception:
                skipped += 1
                continue
        if pk != k:
            continue

        H, V = d.get("H"), d.get("V")
        if H is None or V is None:
            skipped += 1
            continue
        if max(max(H), max(V)) != target_n:
            skipped += 1
            continue

        gap = float(d.get("gap", 0.0))
        if gap < min_gap:
            continue

        if require_triangle_free:
            tf = d.get("triangle_free", None)
            if tf is False:
                continue
            if tf is None and max_clique_at_grid(H, V) > 2:
                continue

        loaded.append((gap, list(H), list(V)))

    loaded.sort(key=lambda t: -t[0])
    loaded = loaded[:max_elites]
    if loaded:
        print(f"  [elite-reuse] k={k}: loaded {len(loaded)} prior elites "
              f"(scanned {scanned}, skipped {skipped}, top gap={loaded[0][0]:.4f})")
    elif scanned > 0:
        print(f"  [elite-reuse] k={k}: no matching elites found "
              f"(scanned {scanned}, skipped {skipped})")

    return loaded


def kbox_seeded_pool(k: int, rng: random.Random, count: int,
                     include_perturbations: bool = True,
                     elite_reuse_dir: Optional[str] = None,
                     elite_reuse_count: int = 8,
                     elite_reuse_min_gap: float = 0.0,
                     elite_reuse_require_tf: bool = False
                     ) -> List[Instance]:
    """Build a pool of seeds at n = 4*k*k mixing k-boxes, variants, motifs."""
    pool: List[Instance] = []
    base_H, base_V = kbox_instance(k)
    pool.append((base_H, base_V))

    # --- NEW: inject saved elites from prior runs ---
    if elite_reuse_dir:
        prior = load_pickle_elites(
            k, elites_dir=elite_reuse_dir,
            max_elites=elite_reuse_count,
            min_gap=elite_reuse_min_gap,
            require_triangle_free=elite_reuse_require_tf,
        )
        for (_gap, H_p, V_p) in prior:
            pool.append((H_p, V_p))
            # and a few perturbations of each prior elite (they've already
            # escaped the basin of attraction of pristine M_k; local search
            # from their neighborhood should find nearby improvements)
            if include_perturbations:
                for _ in range(2):
                    Hx, Vx = H_p, V_p
                    for _step in range(rng.randint(1, 3)):
                        Hx, Vx = perturb_segment_extent(Hx, Vx, rng)
                    pool.append((Hx, Vx))

    if include_perturbations:
        for _ in range(max(2, count // 6)):
            pool.append(shuffle_boxes(base_H, base_V, k, rng))
        for _ in range(max(2, count // 6)):
            box = rng.randint(1, k)
            pool.append(swap_within_box(base_H, base_V, k, box, rng))
        for _ in range(max(2, count // 6)):
            H, V = base_H, base_V
            for _step in range(rng.randint(1, 3)):
                H, V = perturb_segment_extent(H, V, rng)
            pool.append((H, V))

    n = 4 * k * k
    while len(pool) < count:
        if rng.random() < 0.3:
            motifs = motif_seeds(n)
            m = rng.choice(motifs)
            other = random_valid_seq(n, rng)
            if rng.random() < 0.5:
                pool.append(canonicalize(m, other))
            else:
                pool.append(canonicalize(other, m))
        else:
            pool.append(canonicalize(random_valid_seq(n, rng),
                                     random_valid_seq(n, rng)))
    seen: Set[str] = set()
    uniq: List[Instance] = []
    for H, V in pool[:count]:
        key = instance_key(H, V)
        if key in seen:
            continue
        seen.add(key)
        uniq.append((H, V))
    return uniq


# =========================================================================== #
# 2. Triangle-free filter and LP-only scoring                                  #
# =========================================================================== #


def max_clique_at_grid(H: Seq, V: Seq) -> int:
    rects = build_rects(H, V)
    pts = grid_points(rects)
    covers = covers_grid_closed(rects, pts)
    return max((len(c) for c in covers), default=0)


def tfilter_evaluator(H: Seq, V: Seq, grb_threads: int = 0
                      ) -> Optional[Tuple[float, float, float]]:
    if max_clique_at_grid(H, V) > 2:
        return None
    if solve_lp_ilp is None:
        return None
    rects = build_rects(H, V)
    lp, ilp = solve_lp_ilp(rects, grb_threads=grb_threads)
    if ilp <= 0:
        return lp, ilp, 0.0
    return lp, ilp, lp / ilp


def lp_only_score(H: Seq, V: Seq, grb_threads: int = 0) -> Optional[float]:
    try:
        import gurobipy as gp
        from gurobipy import GRB
    except Exception:
        return None
    rects = build_rects(H, V)
    pts = grid_points(rects)
    covers = covers_grid_closed(rects, pts)
    m = gp.Model("misr_lp_only")
    m.setParam("OutputFlag", 0)
    if grb_threads > 0:
        m.setParam("Threads", grb_threads)
    n = len(rects)
    x = m.addVars(n, lb=0.0, ub=1.0, vtype=GRB.CONTINUOUS, name="x")
    m.setObjective(gp.quicksum(x[i] for i in range(n)), GRB.MAXIMIZE)
    for S in covers:
        if len(S) >= 2:
            m.addConstr(gp.quicksum(x[i] for i in S) <= 1)
    m.optimize()
    return float(m.objVal) if m.status == GRB.OPTIMAL else None


# =========================================================================== #
# 3. Padding helper                                                            #
# =========================================================================== #


def assemble_at_n(n: int, rng: random.Random,
                  with_kbox: bool = True) -> Instance:
    if not with_kbox:
        H = random_valid_seq(n, rng)
        V = random_valid_seq(n, rng)
        return canonicalize(H, V)
    k = 0
    while 4 * (k + 1) * (k + 1) <= n:
        k += 1
    if k < 1:
        return canonicalize(random_valid_seq(n, rng),
                            random_valid_seq(n, rng))
    base_H, base_V = kbox_instance(k)
    m = 4 * k * k
    if m == n:
        return canonicalize(base_H, base_V)
    dummies = list(range(m + 1, n + 1))
    H = list(base_H)
    V = list(base_V)
    for d in dummies:
        H.extend([d, d])
        V.extend([d, d])
    return canonicalize(H, V)


# =========================================================================== #
# 4. SAVE HELPERS (robust against silent failure)                              #
# =========================================================================== #


def _safe_save_pickle(path: str, data: dict) -> bool:
    """Pickle dump with explicit error reporting. Returns True on success."""
    try:
        d = os.path.dirname(path) or "."
        os.makedirs(d, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(data, f)
        size = os.path.getsize(path)
        if size == 0:
            print(f"  [SAVE ERROR] wrote 0 bytes to {path}", file=sys.stderr)
            return False
        return True
    except Exception as e:
        print(f"  [SAVE ERROR] {path}: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return False


def save_elite(k: int, r: int, score: float, H: Seq, V: Seq,
               elites_dir: str = ELITES_DIR,
               threshold: float = SAVE_THRESHOLD,
               verbose: bool = True) -> Optional[str]:
    """Save an elite if its score meets the threshold. Returns filename or None."""
    if score < threshold:
        return None
    try:
        mc = max_clique_at_grid(H, V)
        tf = mc <= 2
        n = max(max(H), max(V)) if H else 0
    except Exception as e:
        print(f"  [save_elite] could not compute tf/mc: {e}", file=sys.stderr)
        tf, mc, n = None, None, None
    fname = os.path.join(
        elites_dir,
        f"k{k}_r{r}_gap{score:.4f}_tf{int(tf) if tf is not None else 'NA'}.pkl"
    )
    data = {
        "k": k, "round": r, "H": list(H), "V": list(V),
        "gap": float(score), "triangle_free": tf, "max_clique": mc,
        "n": n, "timestamp": time.time(),
    }
    if _safe_save_pickle(fname, data):
        if verbose:
            print(f"  [SAVED] {fname}  tf={tf}  mc={mc}  n={n}")
        return fname
    return None


def save_final(best_overall: float,
               best_instance: Optional[Instance],
               all_elites: List[Tuple[float, Seq, Seq, int, int]],
               k_start: int, k_end: int,
               final_dir: str = FINAL_DIR) -> None:
    """End-of-run summary. Runs unconditionally."""
    os.makedirs(final_dir, exist_ok=True)
    summary_path = os.path.join(
        final_dir,
        f"final_k{k_start}-{k_end}_gap{best_overall:.4f}.pkl"
    )
    tf = mc = n = None
    if best_instance is not None:
        H_b, V_b = best_instance
        try:
            mc = max_clique_at_grid(H_b, V_b)
            tf = mc <= 2
            n = max(max(H_b), max(V_b))
        except Exception:
            pass
    data = {
        "k_start": k_start, "k_end": k_end,
        "best_overall": float(best_overall),
        "best_instance_H": list(best_instance[0]) if best_instance else None,
        "best_instance_V": list(best_instance[1]) if best_instance else None,
        "best_triangle_free": tf,
        "best_max_clique": mc,
        "best_n": n,
        "all_elites": [
            {"score": float(s), "H": list(H), "V": list(V), "k": k, "round": r}
            for (s, H, V, k, r) in all_elites
        ],
        "timestamp": time.time(),
    }
    if _safe_save_pickle(summary_path, data):
        print(f"\n[FINAL SAVE] {summary_path}")
        print(f"             best_overall={best_overall:.4f}  tf={tf}  mc={mc}  n={n}")
        print(f"             {len(all_elites)} elites recorded")


# =========================================================================== #
# 5. Patched PatternBoost loop                                                 #
# =========================================================================== #


def run_kbox_patternboost(
    k_start: int = 3,
    k_end: int = 6,
    rounds_per_k: int = 10,
    seeds_per_round: int = 32,
    local_time_per_seed: float = 3.0,
    require_triangle_free: bool = True,
    rng_seed: int = 123,
    save_threshold: float = SAVE_THRESHOLD,
    elites_dir: str = ELITES_DIR,
    final_dir: str = FINAL_DIR,
    reuse_elites: bool = True,
    reuse_count: int = 8,
    reuse_min_gap: float = 0.0,
    reuse_require_tf: bool = False,
    use_transformer: bool = False,
    transformer_samples_per_round: int = 8,
    transformer_train_steps_per_round: int = 40,
    transformer_batch_size: int = 16,
    transformer_temperature: float = 1.0,
    transformer_top_p: float = 0.9,
    transformer_elite_pool_size: int = 128,
):
    """
    PatternBoost-style driver with three parallel learning channels:

      1. Pristine k-box seeds (structural scaffolding).
      2. Elite reuse from previously saved pickles (if reuse_elites=True).
      3. Transformer proposer (if use_transformer=True) — trained on the
         accumulated elite pool, samples novel candidate (H, V) each round.

    If use_transformer=True, all three channels feed seeds into each round.
    The transformer is trained incrementally on the full elite pool,
    including any instances loaded from prior pickles.
    """
    if not _HAS_MISTR:
        print("mistr_runner not importable; cannot run.", file=sys.stderr)
        return None, None

    from mistr_runner import local_search

    # --- optional transformer setup ---
    model = None
    opt = None
    transformer_training_pool: List[Tuple[float, Seq, Seq]] = []
    if use_transformer:
        try:
            import torch
            from mistr_runner import TinyGPT, make_batch, sample_model, train_one_step, DEVICE
            print(f"\nTransformer enabled (device={DEVICE}).")
            print(f"  samples/round={transformer_samples_per_round}  "
                  f"train steps/round={transformer_train_steps_per_round}  "
                  f"pool size={transformer_elite_pool_size}")
            model = TinyGPT(d=192, nhead=6, nlayers=3).to(DEVICE)
            opt = torch.optim.AdamW(model.parameters(), lr=2e-4, weight_decay=1e-2)
        except Exception as e:
            print(f"[WARN] transformer setup failed: {e}", file=sys.stderr)
            print("       falling back to search-only mode.", file=sys.stderr)
            model = None
            opt = None

    rng = random.Random(rng_seed)
    best_overall = 0.0
    best_instance: Optional[Instance] = None
    all_elites: List[Tuple[float, Seq, Seq, int, int]] = []

    # Verify output dirs are writable BEFORE the long run starts
    for d in (elites_dir, final_dir):
        try:
            os.makedirs(d, exist_ok=True)
            test_file = os.path.join(d, ".write_test")
            with open(test_file, "w") as f:
                f.write("ok")
            os.remove(test_file)
        except Exception as e:
            print(f"[ERROR] cannot write to {d}: {e}", file=sys.stderr)

    print(f"Save settings: threshold={save_threshold}")
    print(f"  elites_dir: {os.path.abspath(elites_dir)}")
    print(f"  final_dir:  {os.path.abspath(final_dir)}")

    # try/finally ensures final save runs on Ctrl+C or exception
    try:
        for k in range(k_start, k_end + 1):
            n = 4 * k * k
            print(f"\n=== k={k}  (n={n}  target_gap={2*k*k/(k*k+3*k-2):.4f}) ===")
            seeds = kbox_seeded_pool(
                k, rng, seeds_per_round,
                include_perturbations=True,
                elite_reuse_dir=(elites_dir if reuse_elites else None),
                elite_reuse_count=reuse_count,
                elite_reuse_min_gap=reuse_min_gap,
                elite_reuse_require_tf=reuse_require_tf,
            )

            # If transformer is enabled, seed its training pool with the
            # pickle-reused seeds that pass basic validity checks.
            if model is not None:
                for (H, V) in seeds:
                    if max(H) == n:  # sanity
                        # use a neutral score (will get rescored by local_search)
                        transformer_training_pool.append((1.0, list(H), list(V)))

            best_at_k = 0.0
            for r in range(rounds_per_k):
                round_best = 0.0
                round_best_instance: Optional[Instance] = None

                # --- NEW: sample from transformer, add to seeds ---
                transformer_seeds: List[Instance] = []
                if (model is not None
                        and len(transformer_training_pool) >= transformer_batch_size):
                    try:
                        for _ in range(transformer_samples_per_round):
                            h_s, v_s = sample_model(
                                model, n,
                                temperature=transformer_temperature,
                                top_p=transformer_top_p,
                            )
                            if (h_s and v_s
                                    and len(h_s) == 2 * n
                                    and len(v_s) == 2 * n
                                    and max(h_s) == n):
                                transformer_seeds.append((h_s, v_s))
                    except Exception as e:
                        print(f"  [transformer sampling error] {e}",
                              file=sys.stderr)

                # Combine the pool: pristine+reuse seeds from kbox_seeded_pool,
                # plus transformer-generated ones. Transformer seeds go first
                # so they get evaluated even if the budget runs short.
                round_seeds = transformer_seeds + seeds

                for (H, V) in round_seeds:
                    if require_triangle_free and max_clique_at_grid(H, V) > 2:
                        continue
                    es, best = local_search(
                        (H, V),
                        time_budget_s=local_time_per_seed,
                        rng=rng,
                        alpha_lp=0.15,
                        beta_ilp=0.10,
                        grb_threads=0,
                        elite_size=32,
                        neighbor_k=64,
                    )
                    if best is not None:
                        if best > round_best and es:
                            round_best = best
                            round_best_instance = (es[0][1], es[0][2])
                        if best > best_at_k:
                            best_at_k = best
                        if best > best_overall and es:
                            best_overall = best
                            best_instance = (es[0][1], es[0][2])

                        # --- NEW: feed every elite into transformer's
                        # training pool ---
                        if model is not None and es:
                            for (score, h_e, v_e) in es[:8]:
                                transformer_training_pool.append(
                                    (score, list(h_e), list(v_e)))

                # Save every round's best if above threshold
                if (round_best_instance is not None
                        and round_best >= save_threshold):
                    H_rb, V_rb = round_best_instance
                    save_elite(k, r, round_best, H_rb, V_rb,
                               elites_dir=elites_dir,
                               threshold=save_threshold)
                    all_elites.append(
                        (round_best, list(H_rb), list(V_rb), k, r))

                # --- NEW: train transformer on top elites ---
                if model is not None:
                    # keep only top-pool_size by score; larger pool dilutes signal
                    transformer_training_pool.sort(key=lambda t: -t[0])
                    if len(transformer_training_pool) > transformer_elite_pool_size:
                        transformer_training_pool = \
                            transformer_training_pool[:transformer_elite_pool_size]

                    if len(transformer_training_pool) >= transformer_batch_size:
                        last_loss = None
                        try:
                            for _ in range(transformer_train_steps_per_round):
                                batch = make_batch(
                                    transformer_training_pool,
                                    min(transformer_batch_size,
                                        len(transformer_training_pool)),
                                    rng,
                                )
                                last_loss = train_one_step(model, opt, batch)
                        except Exception as e:
                            print(f"  [transformer training error] {e}",
                                  file=sys.stderr)
                        if last_loss is not None:
                            extra = (f"  xf_loss={last_loss:.3f}  "
                                     f"pool={len(transformer_training_pool)}")
                        else:
                            extra = ""
                    else:
                        extra = (f"  xf_pool={len(transformer_training_pool)}"
                                 f"/{transformer_batch_size}")
                else:
                    extra = ""

                print(f"  round {r+1}/{rounds_per_k}  "
                      f"best_this_round={round_best:.4f}"
                      f"  best_at_k={best_at_k:.4f}"
                      f"  best_overall={best_overall:.4f}"
                      f"{extra}")

        print(f"\n=== DONE ===\nbest_overall={best_overall:.4f}")
    finally:
        save_final(best_overall, best_instance, all_elites,
                   k_start, k_end, final_dir=final_dir)

    return best_overall, best_instance


# =========================================================================== #
# 6. Standalone smoke tests                                                    #
# =========================================================================== #


def _smoke():
    rng = random.Random(0)
    for k in (2, 3, 4, 5):
        pool = kbox_seeded_pool(k, rng, count=8, include_perturbations=True)
        print(f"k={k}  pool_size={len(pool)}")
        H, V = pool[0]
        mc = max_clique_at_grid(H, V)
        print(f"  pristine triangle-free: {mc <= 2}  max_clique_at_grid={mc}")
        shuffled = shuffle_boxes(H, V, k, rng)
        mc2 = max_clique_at_grid(*shuffled)
        print(f"  shuffled triangle-free: {mc2 <= 2}  max_clique_at_grid={mc2}")
        swapped = swap_within_box(H, V, k, box=1, rng=rng)
        mc3 = max_clique_at_grid(*swapped)
        print(f"  swapped-within-box(1) max_clique_at_grid={mc3}")


def _save_smoke():
    """Verify save logic works end-to-end."""
    print("Save smoke test...")
    H, V = kbox_instance(3)
    tmp_dir = "/tmp/save_smoke_elites"
    fname = save_elite(k=3, r=0, score=1.5000, H=H, V=V,
                       elites_dir=tmp_dir, threshold=1.0, verbose=True)
    print(f"  save_elite returned: {fname}")
    if fname and os.path.exists(fname):
        with open(fname, "rb") as f:
            d = pickle.load(f)
        print(f"  re-loaded: gap={d['gap']} tf={d['triangle_free']} "
              f"mc={d['max_clique']} n={d['n']}")
        os.remove(fname)
        try:
            os.rmdir(tmp_dir)
        except OSError:
            pass
        print("  save logic works.")
    else:
        print("  save FAILED.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--save-smoke", action="store_true")
    ap.add_argument("--verify-all", action="store_true")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--k-start", type=int, default=3)
    ap.add_argument("--k-end", type=int, default=6)
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--seeds-per-round", type=int, default=16)
    ap.add_argument("--local-time", type=float, default=2.0)
    ap.add_argument("--save-threshold", type=float, default=SAVE_THRESHOLD)
    ap.add_argument("--elites-dir", default=ELITES_DIR)
    ap.add_argument("--final-dir", default=FINAL_DIR)
    ap.add_argument("--no-reuse", action="store_true",
                    help="disable loading prior elites from --elites-dir")
    ap.add_argument("--reuse-count", type=int, default=8,
                    help="max prior elites to load per k")
    ap.add_argument("--reuse-min-gap", type=float, default=0.0,
                    help="only reuse prior elites with gap >= this")
    ap.add_argument("--reuse-tf-only", action="store_true",
                    help="only reuse triangle-free prior elites")
    ap.add_argument("--use-transformer", action="store_true",
                    help="enable TinyGPT proposer (trained on elite pool)")
    ap.add_argument("--xf-samples", type=int, default=8,
                    help="transformer samples per round")
    ap.add_argument("--xf-steps", type=int, default=40,
                    help="transformer training steps per round")
    ap.add_argument("--xf-batch", type=int, default=16,
                    help="transformer training batch size")
    ap.add_argument("--xf-temp", type=float, default=1.0,
                    help="transformer sampling temperature")
    ap.add_argument("--xf-top-p", type=float, default=0.9,
                    help="transformer sampling top-p")
    ap.add_argument("--xf-pool", type=int, default=128,
                    help="max elites kept in transformer training pool")
    args = ap.parse_args()

    if args.save_smoke:
        _save_smoke()
        return
    if args.smoke:
        _smoke()
        return
    if args.verify_all:
        print(f"{'k':>3} {'n':>6} {'alpha*':>8} {'alpha':>8} {'gap':>8} {'ok':>6}")
        for k in range(2, 8):
            ok = verify(k, verbose=False)
            print(f"{k:>3} {4*k*k:>6} {2*k*k:>8} {k*k+3*k-2:>8} "
                  f"{2*k*k/(k*k+3*k-2):>8.4f} {'PASS' if ok else 'FAIL':>6}")
        return
    if args.run:
        run_kbox_patternboost(
            k_start=args.k_start,
            k_end=args.k_end,
            rounds_per_k=args.rounds,
            seeds_per_round=args.seeds_per_round,
            local_time_per_seed=args.local_time,
            save_threshold=args.save_threshold,
            elites_dir=args.elites_dir,
            final_dir=args.final_dir,
            reuse_elites=not args.no_reuse,
            reuse_count=args.reuse_count,
            reuse_min_gap=args.reuse_min_gap,
            reuse_require_tf=args.reuse_tf_only,
            use_transformer=args.use_transformer,
            transformer_samples_per_round=args.xf_samples,
            transformer_train_steps_per_round=args.xf_steps,
            transformer_batch_size=args.xf_batch,
            transformer_temperature=args.xf_temp,
            transformer_top_p=args.xf_top_p,
            transformer_elite_pool_size=args.xf_pool,
        )
        return
    _smoke()


if __name__ == "__main__":
    main()
